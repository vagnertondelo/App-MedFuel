package principal;

import android.app.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import br.com.unoesc.medfuel.R;
import buscar.BuscarFragment;
import combustivel.CombustivelCADActivity;
import combustivel.CombustivelDAO;
import combustivel.CombustivelListaFragment;
import guia.GuiaFragment;
import mapaAbastecida.MapaAbastecidaActivity;
import sobre.SobreFragment;

public class PincipalActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    CombustivelDAO combustivelDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pincipal);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //      .setAction("Action", null).show();

                Intent it= new Intent(PincipalActivity.this, CombustivelCADActivity.class);
                startActivityForResult(it,1);
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        combustivelDAO = new CombustivelDAO(this);
        combustivelDAO.listar();
        setDisplay(R.id.nav_todas);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.pincipal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {



        setDisplay(item.getItemId());

        return true;

    }

    public void setDisplay(int position) {
        Fragment fragment;


        switch (position){

            case R.id.nav_todas:
                fragment= new CombustivelListaFragment();
                abrirFragment(fragment,"Lista de Abastecidas");
                break;

            case R.id.nav_busca:
                fragment=new BuscarFragment();
                abrirFragment(fragment,"Buscar");
                break;


            case R.id.nav_mapa:
                Intent it = new Intent(this, MapaAbastecidaActivity.class);
                startActivity(it);

                break;

            case R.id.nav_sobre:
                fragment= new SobreFragment();
                abrirFragment(fragment,"Sobre");
                break;

            case R.id.nav_guia:
                fragment= new GuiaFragment();
                abrirFragment(fragment,"Guia");
                break;

        }
    }



    public void abrirFragment(Fragment fragment, String title){
        //gerencia os layout
        if (fragment !=null){
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.container_body,fragment);
            fragmentTransaction.commit();

            //set tituulo
            getSupportActionBar().setTitle(title);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }


    /*
    @Override
    public void startActivityForResult(Intent intent, int requestCode) {
        super.startActivityForResult(intent, requestCode);
        setDisplay(R.id.nav_todas);
    }
    */


}
