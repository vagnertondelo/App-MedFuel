package mapaAbastecida;
import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;

import br.com.unoesc.medfuel.R;
import combustivel.Combustivel;
import combustivel.CombustivelDAO;
import gps.GpsService;

/**
 * Created by vagner on 12/12/16.
 */
public class MapaAbastecidaActivity extends AppCompatActivity implements AdapterView.OnItemClickListener,OnMapReadyCallback {

    Combustivel combustivel;
    CombustivelDAO combustivelDAO;
    List<Combustivel>combustiveis;
    GpsService gpsService = new GpsService(this);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_mapa_abastecida);

        combustivelDAO = new CombustivelDAO(this);
        combustiveis=combustivelDAO.listar();
        //cria seta de voltar na tela
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //pega posição do br.com.unoesc.medful.gps
        gpsService = new GpsService(this);

        MapFragment  mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        GoogleMap map=mapFragment.getMap();
        map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        mapFragment.getMapAsync(this);
    }




    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onMapReady(GoogleMap map) {

        for (Combustivel combustivel:combustiveis) {
            Double lat = Double.valueOf(combustivel.getLatitude());
            Double lon = Double.valueOf(combustivel.getLongitude());
            LatLng latLng = new LatLng(lat, lon);
            //cria marcador
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.title("Nome Posto: "+ combustivel.getNomePosto());
            markerOptions.snippet("Motorista: "+ combustivel.getMotorista());
            markerOptions.position(latLng);
            //move a camera e zoom para ponto expecifico
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
            map.addMarker(markerOptions);

        };

    }

    //ação seta voltar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }


}
