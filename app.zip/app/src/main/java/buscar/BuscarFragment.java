package buscar;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

import br.com.unoesc.medfuel.R;
import combustivel.Combustivel;
import combustivel.CombustivelActivity;
import combustivel.CombustivelDAO;
import combustivel.CombustivelListAdapter;

public class BuscarFragment extends Fragment implements AdapterView.OnItemClickListener {
    EditText edtBusca;
    Button btnBuscar;
    List<Combustivel> combustivel;
    CombustivelDAO combustivelDAO= new CombustivelDAO(getActivity());
    CombustivelListAdapter adapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_buscar,container,false);
        //lista
        ListView listView = (ListView) view.findViewById(R.id.fragment_combustivel_list_busca_listview);
        // mostra vazio se não tiver nada
        listView.setEmptyView(view.findViewById(android.R.id.empty));
        //botaõa para chamar a tela denuncia
        listView.setOnItemClickListener(this);

        CombustivelDAO combustivelDAO= new CombustivelDAO(getActivity());
        combustivel = combustivelDAO.listar();
        CombustivelListAdapter adapter = new CombustivelListAdapter(getActivity(),R.layout.fragment_combustivel_list_item,combustivel);
        listView.setAdapter(adapter);

         edtBusca = (EditText)view.findViewById(R.id.fragment_busca_edtmotorista);
         btnBuscar = (Button)view.findViewById(R.id.btn_Busca_Fragment);


        return view;
    }

    //onClik para chamar a tela nova
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        Combustivel combustivell =  combustivel.get(position);

        Intent it=new Intent(getActivity(),CombustivelActivity.class);
        String id1 = String.valueOf(combustivell.getId());
        it.putExtra(Combustivel.ID,id1);
        startActivityForResult(it,1);

    }
    public void busca_valor(){
        CombustivelDAO combustivelDAO= new CombustivelDAO(getActivity());
        String busca = edtBusca.getText().toString();
        combustivel= combustivelDAO.buscavalor(busca);
        atualizaLista();


    }

    public void atualizaLista(){
        List<Combustivel> cs = combustivelDAO.listar();

        adapter.clear();
        adapter.addAll(cs);

        adapter.notifyDataSetChanged();
    }

}
