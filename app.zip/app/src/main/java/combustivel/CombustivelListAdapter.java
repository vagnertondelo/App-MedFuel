package combustivel;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import br.com.unoesc.medfuel.R;

/**
 * Created by vagner on 08/12/16.
 */
public class CombustivelListAdapter extends ArrayAdapter<Combustivel> {
    int layout;
    Context context;
    List<Combustivel> combustivels;
    Bitmap bmimage;

    public CombustivelListAdapter(Context context, int layout, List<Combustivel> combustivel) {
        super(context, layout, combustivel);
        this.layout = layout;
        this.context = context;
        this.combustivels = combustivel;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(layout,null);


        TextView tvData = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvdata);
        TextView tvHora = (TextView) view.findViewById(R.id.fragment_combustivel_listt_tvhora);
        TextView tvMotorista= (TextView) view.findViewById(R.id.fragment_combustivel_list_tvmotorista);
        TextView tvPlaca = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvPlaca);
        TextView tvNomePosto = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvnomeposto);
        TextView tvKMAtual = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvKMatual);
        TextView tvLitros = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvlitros);
        TextView tvValorLitro = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvvalor);
        // TextView tvLongitude = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvlongitude);
        //  TextView tvLatitude = (TextView) view.findViewById(R.id.fragment_combustivel_list_tvlatitude);
        ImageView imfoto = (ImageView) view.findViewById(R.id.fragment_combustivel_list_imFoto);


        final Combustivel combustivel = combustivels.get(position);
        tvData.setText(combustivel.getDataAbastecida());
        tvHora.setText(combustivel.getHora());
        tvKMAtual.setText(combustivel.getKmAtual());
        // tvLatitude.setText(br.com.unoesc.medful.combustivel.getLatitude());
        tvLitros.setText(combustivel.getLitro());
        // tvLongitude.setText(br.com.unoesc.medful.combustivel.getLongitude());
        tvMotorista.setText(combustivel.getMotorista());
        tvNomePosto.setText(combustivel.getNomePosto());
        tvPlaca.setText(combustivel.getPlaca());
        tvValorLitro.setText(combustivel.getValorPorLitro());

        //decodifica e set a imagem
        byte[] bytarray = Base64.decode(combustivel.getFoto(), Base64.DEFAULT);
        bmimage= BitmapFactory.decodeByteArray(bytarray, 0 ,bytarray.length);
        imfoto.setImageBitmap(bmimage);
        return view;
    }
}