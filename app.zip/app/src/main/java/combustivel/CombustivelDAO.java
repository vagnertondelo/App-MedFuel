package combustivel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import sqlite.BancoDados;

/**
 * Created by vagner on 01/12/16.
 */
public class CombustivelDAO {
    SQLiteDatabase db;

    public CombustivelDAO(Context context){
        db = BancoDados.getDB(context);

    }

    public void salvar(Combustivel combustivel){
        ContentValues values = new ContentValues();

        values.put(Combustivel.DATAABASTECIDA,combustivel.getDataAbastecida());
        values.put(Combustivel.KMATUAL,combustivel.getKmAtual());
        values.put(Combustivel.LITROS,combustivel.getLitro());
        values.put(Combustivel.NOMEPOSTO,combustivel.getNomePosto());
        values.put(Combustivel.VALORPORLITROS,combustivel.getValorPorLitro());
        values.put(Combustivel.PLACA,combustivel.getPlaca());
        values.put(Combustivel.MOTORISTA,combustivel.getMotorista());
        values.put(Combustivel.LONGITUDE,combustivel.getLongitude());
        values.put(Combustivel.LATITUDE,combustivel.getLatitude());
        values.put(Combustivel.HORA,combustivel.getHora());
        values.put(Combustivel.FOTO,combustivel.getFoto());
        db.insert(Combustivel.TABELA,null,values);
    }



    public void alterar(Combustivel combustivel){
        ContentValues values = new ContentValues();
        values.put(Combustivel.DATAABASTECIDA,combustivel.getDataAbastecida());
        values.put(Combustivel.KMATUAL,combustivel.getKmAtual());
        values.put(Combustivel.LITROS,combustivel.getLitro());
        values.put(Combustivel.NOMEPOSTO,combustivel.getNomePosto());
        values.put(Combustivel.VALORPORLITROS,combustivel.getValorPorLitro());
        values.put(Combustivel.PLACA,combustivel.getPlaca());
        values.put(Combustivel.MOTORISTA,combustivel.getMotorista());
        values.put(Combustivel.LONGITUDE,combustivel.getLongitude());
        values.put(Combustivel.LATITUDE,combustivel.getLatitude());
        values.put(Combustivel.HORA,combustivel.getHora());
        values.put(Combustivel.FOTO,combustivel.getFoto());

        String id = String.valueOf(combustivel.getId());
        String[] whereArgs = new String[]{id};

        db.update(Combustivel.TABELA,values,Combustivel.ID+"= ?",whereArgs);
    }

    public void excluir(String id){
        String[] whereArgs = new String[]{id};
        db.delete(Combustivel.TABELA,Combustivel.ID+"= ?",whereArgs);
    }

    public Combustivel buscar(String id) {


        String[] whereArgs = new String[]{id};

        Cursor c = db.query(Combustivel.TABELA, Combustivel.COLUNAS, Combustivel.ID + "= ?", whereArgs, null, null, null);

        if (c.moveToFirst()) {
            ;

            Combustivel combustivel = new Combustivel();
            combustivel.setId(c.getLong(c.getColumnIndex(Combustivel.ID)));
            combustivel.setDataAbastecida(c.getString(c.getColumnIndex(Combustivel.DATAABASTECIDA)));
            combustivel.setKmAtual(c.getString(c.getColumnIndex(Combustivel.KMATUAL)));
            combustivel.setLitro(c.getString(c.getColumnIndex(Combustivel.LITROS)));
            combustivel.setNomePosto(c.getString(c.getColumnIndex(Combustivel.NOMEPOSTO)));
            combustivel.setValorPorLitro(c.getString(c.getColumnIndex(Combustivel.VALORPORLITROS)));
            combustivel.setPlaca(c.getString(c.getColumnIndex(Combustivel.PLACA)));
            combustivel.setMotorista(c.getString(c.getColumnIndex(Combustivel.MOTORISTA)));
            combustivel.setHora(c.getString(c.getColumnIndex(Combustivel.HORA)));
            combustivel.setLatitude(c.getString(c.getColumnIndex(Combustivel.LATITUDE)));
            combustivel.setLongitude(c.getString(c.getColumnIndex(Combustivel.LONGITUDE)));
            combustivel.setFoto(c.getString(c.getColumnIndex(Combustivel.FOTO)));


            return combustivel;
        }
        else{
            return null;
        }
    }

    public List<Combustivel> listar(){

        Cursor c = db.query(Combustivel.TABELA,Combustivel.COLUNAS,null,null,null,null,Combustivel.ID+" desc");

        List<Combustivel> combustiveis = new ArrayList<Combustivel>();
        if(c.moveToFirst()){
            do{
                Combustivel  combustivel = new Combustivel();
                combustivel.setId(c.getLong(c.getColumnIndex(Combustivel.ID)));
                combustivel.setDataAbastecida(c.getString(c.getColumnIndex(Combustivel.DATAABASTECIDA)));
                combustivel.setKmAtual(c.getString(c.getColumnIndex(Combustivel.KMATUAL)));
                combustivel.setLitro(c.getString(c.getColumnIndex(Combustivel.LITROS)));
                combustivel.setNomePosto(c.getString(c.getColumnIndex(Combustivel.NOMEPOSTO)));
                combustivel.setValorPorLitro(c.getString(c.getColumnIndex(Combustivel.VALORPORLITROS)));
                combustivel.setPlaca(c.getString(c.getColumnIndex(Combustivel.PLACA)));
                combustivel.setMotorista(c.getString(c.getColumnIndex(Combustivel.MOTORISTA)));
                combustivel.setLongitude(c.getString(c.getColumnIndex(Combustivel.LONGITUDE)));
                combustivel.setLatitude(c.getString(c.getColumnIndex(Combustivel.LATITUDE)));
                combustivel.setHora(c.getString(c.getColumnIndex(Combustivel.HORA)));
                combustivel.setFoto(c.getString(c.getColumnIndex(Combustivel.FOTO)));


                Log.i("lista",combustivel.getDataAbastecida());
                Log.i("lista",combustivel.getNomePosto());
                combustiveis.add(combustivel);
            }while (c.moveToNext());
        }
        return combustiveis;
    }


    // lista com filtro para buscar valores expecificos

    public List<Combustivel> buscavalor(String motorista){
        String filtro = "";
        String and = "";


        if (motorista instanceof String && !motorista.equals("")){
            filtro = filtro + and + Combustivel.MOTORISTA + "like" +motorista.trim() +"%' ";
            and = "and";
        }




        //ultimo null é a ordem da lista sempre com o espaço depoois do aspas
        Cursor c = db.query(Combustivel.TABELA,Combustivel.COLUNAS,filtro,null,null,null,null,Combustivel.ID+" desc");

        List<Combustivel> combustivelList = new ArrayList<Combustivel>();
        if(c.moveToFirst()){
            do{

                Combustivel  combustivel = new Combustivel();
                combustivel.setId(c.getLong(c.getColumnIndex(Combustivel.ID)));
                combustivel.setDataAbastecida(c.getString(c.getColumnIndex(Combustivel.DATAABASTECIDA)));
                combustivel.setKmAtual(c.getString(c.getColumnIndex(Combustivel.KMATUAL)));
                combustivel.setLitro(c.getString(c.getColumnIndex(Combustivel.LITROS)));
                combustivel.setNomePosto(c.getString(c.getColumnIndex(Combustivel.NOMEPOSTO)));
                combustivel.setValorPorLitro(c.getString(c.getColumnIndex(Combustivel.VALORPORLITROS)));
                combustivel.setPlaca(c.getString(c.getColumnIndex(Combustivel.PLACA)));
                combustivel.setMotorista(c.getString(c.getColumnIndex(Combustivel.MOTORISTA)));
                combustivel.setLongitude(c.getString(c.getColumnIndex(Combustivel.LONGITUDE)));
                combustivel.setLatitude(c.getString(c.getColumnIndex(Combustivel.LATITUDE)));
                combustivel.setHora(c.getString(c.getColumnIndex(Combustivel.HORA)));
                combustivel.setFoto(c.getString(c.getColumnIndex(Combustivel.FOTO)));

                combustivelList.add(combustivel);
            }while (c.moveToNext());
        }
        return combustivelList;
    }





}
