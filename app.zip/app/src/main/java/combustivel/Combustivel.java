package combustivel;

import android.text.Editable;

/**
 * Created by vagner on 01/12/16.
 */
public class Combustivel {

    private Long id;

    private String nomePosto;
    private String dataAbastecida;
    private String kmAtual;
    private String litro;
    private String valorPorLitro;
    private String placa;
    private String motorista;
    private String hora;
    private String latitude;
    private String longitude;
    private String foto;


    public  static final String ID = "_id";
    public static final String NOMEPOSTO ="nomePosto";
    public static final String DATAABASTECIDA= "dataAbastecida";
    public  static final String KMATUAL="kmAtual";
    public static final String LITROS= "litro";
    public static final String VALORPORLITROS="valorPorLitro";
    public static final String PLACA="placa";
    public static final String MOTORISTA="motorista";
    public static final String HORA="hora";
    public static final String LATITUDE="latitude";
    public static final String LONGITUDE="longitude";
    public static final String FOTO="foto";

    public static final String TABELA = "tbl_MedFuel";
    public static final String[] COLUNAS = {ID,NOMEPOSTO,DATAABASTECIDA,KMATUAL,LITROS,VALORPORLITROS,PLACA,MOTORISTA,HORA,LATITUDE,LONGITUDE,FOTO};

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomePosto() {
        return nomePosto;
    }

    public void setNomePosto(String nomePosto) {
        this.nomePosto = nomePosto;
    }

    public String getDataAbastecida() {
        return dataAbastecida;
    }

    public void setDataAbastecida(String dataAbastecida) {
        this.dataAbastecida = dataAbastecida;
    }

    public String getKmAtual() {
        return kmAtual;
    }

    public void setKmAtual(String kmAtual) {
        this.kmAtual = kmAtual;
    }

    public String getLitro() {
        return litro;
    }

    public void setLitro(String litro) {
        this.litro = litro;
    }

    public String getValorPorLitro() {
        return valorPorLitro;
    }

    public void setValorPorLitro(String valorPorLitro) {
        this.valorPorLitro = valorPorLitro;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMotorista() {
        return motorista;
    }

    public void setMotorista(String motorista) {
        this.motorista = motorista;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
}
