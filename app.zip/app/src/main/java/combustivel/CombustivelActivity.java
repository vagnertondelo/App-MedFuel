package combustivel;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import br.com.unoesc.medfuel.R;
import gps.GpsService;

/**
 * Created by vagner on 08/12/16.
 */
public class CombustivelActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {
    TextView data, longitude, latitude, motorista, litros, valorlitro, placa, nomeposto, hora, kmatual;
    ImageView ivFoto;
    //instancia br.com.unoesc.medful.gps
    GpsService gpsService = new GpsService(this);
    Combustivel combustivel;
    CombustivelDAO combustivelDAO;
    Bitmap bmimage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_combustivel);



        //cria seta de voltar na tela
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        nomeposto = (TextView) findViewById(R.id.activity_combustivel_tvnomeposto);
        hora = (TextView) findViewById(R.id.activity_combustivel_tvhora);
        kmatual = (TextView) findViewById(R.id.activity_combustivel_tvKMatual);
        litros = (TextView) findViewById(R.id.activity_combustivel_tvlitros);
        placa = (TextView) findViewById(R.id.activity_combustivel_tvPlaca);
        motorista = (TextView) findViewById(R.id.activity_combustivel_tvmotorista);
        valorlitro = (TextView) findViewById(R.id.activity_combustivel_tvvalor);
        latitude = (TextView) findViewById(R.id.activity_combustivel_tvlatitude);
        longitude = (TextView) findViewById(R.id.activity_combustivel_tvlongitude);
        data = (TextView) findViewById(R.id.activity_combustivel_tvdata);

        Intent it = getIntent();
        if (it!=null) {
            String id = it.getStringExtra(Combustivel.ID);
            //instacia o dao e id e seta na tela
            CombustivelDAO combustivelDAO = new CombustivelDAO(this);
            Combustivel combustivel = combustivelDAO.buscar(id);
            Toast.makeText(this, id, Toast.LENGTH_LONG).show();
            nomeposto.setText(combustivel.getNomePosto());
            hora.setText(combustivel.getHora());
            kmatual.setText(combustivel.getKmAtual());
            litros.setText(combustivel.getLitro());
            placa.setText(combustivel.getPlaca());
            motorista.setText(combustivel.getMotorista());
            valorlitro.setText(combustivel.getValorPorLitro());
            latitude.setText(combustivel.getLatitude());
            longitude.setText(combustivel.getLatitude());
            data.setText(combustivel.getDataAbastecida());
            //decodifica imagem
            ivFoto=(ImageView)findViewById(R.id.activity_combustivel_ivFoto);
            byte[] bytarray = Base64.decode(combustivel.getFoto(), Base64.DEFAULT);
            bmimage= BitmapFactory.decodeByteArray(bytarray, 0 ,bytarray.length);
            ivFoto.setImageBitmap(bmimage);
            ivFoto.setOnClickListener(this);

        }
        MapFragment  mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        GoogleMap map=mapFragment.getMap();
        map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        mapFragment.getMapAsync(this);
        //pega posição do br.com.unoesc.medful.gps
        gpsService = new GpsService(this);


    }


    //ação seta voltar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    @Override
    public void onMapReady(GoogleMap map) {
        Intent it = getIntent();
        String id = it.getStringExtra(Combustivel.ID);
        CombustivelDAO combustivelDAO = new CombustivelDAO(this);
        Combustivel combustivel = combustivelDAO.buscar(id);

        //pega posição do br.com.unoesc.medful.gps e salva
       // LatLng latLng = new LatLng (gpsService.getLatitude(),gpsService.getLongitude());


        Double lat = Double.valueOf(combustivel.getLatitude());
        Double lon = Double.valueOf(combustivel.getLongitude());
        LatLng latLng = new LatLng(lat, lon);
        //cria marcador
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.title("Nome Posto: "+ combustivel.getNomePosto());
        markerOptions.snippet("Motorista: "+ combustivel.getMotorista());
        markerOptions.position(latLng);
        //move a camera e zoom para ponto expecifico
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17));
        map.addMarker(markerOptions);
    }

    @Override
    public void onClick(View view) {
        final Dialog dialog= new Dialog(this);
        dialog.setContentView(R.layout.dialog_foto);

        dialog.setTitle("Cupom Fiscal");
        ImageView ifoto = (ImageView) dialog.findViewById(R.id.dialog_foto_imfoto);
        ifoto.setImageBitmap(bmimage);
        dialog.show();
    }
}