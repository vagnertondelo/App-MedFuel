package combustivel;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

import br.com.unoesc.medfuel.R;
import gps.GpsService;

/**
 * Created by vagner on 04/12/16.
 */
public class CombustivelCADActivity  extends AppCompatActivity {
    private TextView tvData,tvhora;
    private EditText edtplaca,edtmotorista,edtkmatual,edtnomeposto,edtdata,edtvalor,edtlitros,edtlongitude,edtlatitude,edthora;
    private CombustivelDAO combustivelDAO ;
    private GpsService gpsService;
    private ImageView imFoto;
    //string para salvar foto no banco
    String strFoto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combustibvel_cad);
        //cria seta de voltar na tela
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        edtdata = (EditText)findViewById(R.id.combustivel_cad_edtdata);
        edtkmatual =(EditText)findViewById(R.id.combustivel_cad_edtkmatual);
        edtlitros =(EditText)findViewById(R.id.combustivel_cad_edtlitros);
        edtmotorista =(EditText)findViewById(R.id.combustivel_cad_edtmotorista);
        edtplaca =(EditText)findViewById(R.id.combustivel_cad_edtplaca);
        edtnomeposto =(EditText)findViewById(R.id.combustivel_cad_edtnomeposto);
        edtvalor =(EditText)findViewById(R.id.combustivel_cad_edtvalor);
        edthora =(EditText)findViewById(R.id.combustivel_cad_edthora);
        //edtlatitude =(EditText)findViewById(R.id.combustivel_cad_edtlatitude);
        //  edtlongitude =(EditText)findViewById(R.id.combustivel_cad_edtlongitude);
        imFoto=(ImageView) findViewById(R.id.denuncia_cad_imFoto);

        chamadata();
        chamahora();
        combustivelDAO = new CombustivelDAO(this);
        gpsService = new GpsService(this);
    }


    //ação seta voltar
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }


    public void salvarDenuncia(View v){
        Combustivel combustivel = new Combustivel();
        combustivel.setMotorista(edtmotorista.getText().toString());
        combustivel.setPlaca(edtplaca.getText().toString());
        combustivel.setNomePosto(edtnomeposto.getText().toString());
        combustivel.setValorPorLitro(edtvalor.getText().toString());
        combustivel.setDataAbastecida(edtdata.getText().toString());
        combustivel.setKmAtual(edtkmatual.getText().toString());
        combustivel.setLatitude(String.valueOf(gpsService.getLatitude()));
        combustivel.setLongitude(String.valueOf(gpsService.getLongitude()));
        combustivel.setHora(edthora.getText().toString());
        combustivel.setLitro(edtlitros.getText().toString());
        combustivel.setFoto(strFoto);


        combustivelDAO.salvar(combustivel);

        Toast.makeText(getApplicationContext(), "Salva com sucesso", Toast.LENGTH_LONG).show();
        finish();


    }

    //implementa a foto com bitmap
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data != null) {

            Bundle bundle = data.getExtras();
            Bitmap bitmap = (Bitmap) bundle.get("data");

            imFoto.setImageBitmap(bitmap);

            //converte a foto em estrig para salvar
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG,100,baos);
            byte[] bytes = baos.toByteArray();
            strFoto = Base64.encodeToString(bytes,Base64.DEFAULT);
        }
    }

    public void capturarFoto(View v){

        Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(it,0);

    }
    public void chamahora() {
        //implementa a hora
        tvhora = (TextView) findViewById(R.id.combustivel_cad_edthora);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        Date hora = Calendar.getInstance().getTime(); // Ou qualquer outra forma que tem
        String dataFormatada =String.valueOf( sdf.format(hora));
        tvhora.setText("" + dataFormatada);


    }
    public void chamadata(){
        //implementa a data
        tvData= (TextView) findViewById(R.id.combustivel_cad_edtdata);
        String currentDateTimeString = DateFormat.getDateInstance().format(new Date());
        tvData.setText("" + currentDateTimeString);

    }

}


